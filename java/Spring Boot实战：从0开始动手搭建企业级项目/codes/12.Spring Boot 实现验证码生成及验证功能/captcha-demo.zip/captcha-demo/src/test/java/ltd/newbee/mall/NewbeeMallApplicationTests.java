package ltd.newbee.mall;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class NewbeeMallApplicationTests {

	@Test
	void contextLoads() {
	}

	@Test
	void test(){
		System.out.println("---------");
		System.out.println(null+"");
		System.out.println("---------");
	}
}
