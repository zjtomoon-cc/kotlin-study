package ltd.newbee.mall.dao;

import ltd.newbee.mall.entity.MallUser;
import org.apache.ibatis.annotations.Param;

public interface MallUserMapper {

    /**
     * 保存一条新记录
     * @param record
     * @return
     */
    int insertSelective(MallUser record);

    /**
     * 根据loginName查询记录
     * @param loginName
     * @return
     */
    MallUser selectByLoginName(String loginName);

    /**
     * 根据loginName和密码字段查询记录
     * @param loginName
     * @return
     */
    MallUser selectByLoginNameAndPasswd(@Param("loginName") String loginName, @Param("password") String password);
}